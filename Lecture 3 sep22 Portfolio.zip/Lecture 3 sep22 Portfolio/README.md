Browser Blog
===

To run:

1. make a new folder and open it in vscode or your favourite IDE
2. `git clone https://github.com/rhildred/browserBlog.git .`
3. `npx http-server` (you will need to install node.js for this to work)
4. surf to [http://localhost:8080](http://localhost:8080)

This is a project that uses markdown, html5 and es6 to make a single page blog or portfolio. Look in the pages or items folder to see the markdown and the index.js meta-data.