export default [{"id": "item1", "fname":"category1.md", "specialImage":"/img/FavouriteFoodBaskets750x500_xraj9x.png"},
{"id": "item2", "fname":"category2.md", "specialImage":"/img/FavouriteDay750x500_pdni4p.png"},
{"id": "item3", "fname":"category3.md", "specialImage":"/img/twiliobot750x500_z7anzp.png"},
{"id": "item4", "fname":"category4.md", "specialImage":"https://res.cloudinary.com/salesucation-com-inc/image/upload/v1523215138/DroidfootGame750x500_bwphbe.png"}];