export default [{"title":"About", "fname":"about.md", "specialImage":"/img/menagerie.png"},
{"title":"index", "fname":"index.md"},
{"title":"Contact", "fname":"contact.md"}];